"""Separation engine (demucs-onnx)."""
import os
import shutil

import numpy as np
import soundfile as sf

from .audio_io import convert_to_wav, needs_ffmpeg_conversion
from .resources import DEMUCS_IMPORT_ERROR

if DEMUCS_IMPORT_ERROR is None:
    import demucs_onnx
else:
    demucs_onnx = None


def separate_file(input_path, output_dir, model_name,
                  providers="auto", precision="fp32",
                  chunked=False, chunk_seconds=60, progress_cb=None):
    if DEMUCS_IMPORT_ERROR:
        raise RuntimeError("demucs-onnx unavailable: "
                           + DEMUCS_IMPORT_ERROR)

    def emit(pct, msg):
        if progress_cb:
            progress_cb(int(pct), str(msg))

    converted = None
    input_to_use = input_path
    try:
        if needs_ffmpeg_conversion(input_path):
            emit(1, "Converting input to WAV...")
            try:
                converted = convert_to_wav(input_path)
                input_to_use = converted
                emit(5, "Conversion complete.")
            except RuntimeError as e:
                raise RuntimeError(str(e))

        os.makedirs(output_dir, exist_ok=True)

        if chunked:
            return _run_chunked(input_to_use, output_dir, model_name,
                                providers, precision, chunk_seconds, emit)
        return _run_single_pass(input_to_use, output_dir, model_name,
                                providers, precision, emit)
    finally:
        if converted and os.path.exists(converted):
            try:
                os.remove(converted)
            except OSError:
                pass


def _run_single_pass(input_path, output_dir, model_name,
                     providers, precision, emit):
    emit(10, "Loading model and separating...")
    kwargs = dict(model=model_name, providers=providers,
                  precision=precision, progress=False)
    emit(20, "Running separation (this may take a while)...")
    result = demucs_onnx.separate(input_path, output_dir, **kwargs)
    emit(95, "Finalizing...")
    normalized = _normalize_result(result)
    emit(100, "Done")
    return normalized


def _run_chunked(input_path, output_dir, model_name, providers,
                 precision, chunk_seconds, emit):
    emit(10, "Reading audio file...")
    audio, sr = sf.read(input_path, dtype="float32", always_2d=True)
    total_frames = audio.shape[0]
    chunk_frames = int(chunk_seconds * sr)
    n_chunks = max(1, (total_frames + chunk_frames - 1) // chunk_frames)

    stem_chunks = {}
    tmp_dir = os.path.join(output_dir, "_tmp_chunks")
    os.makedirs(tmp_dir, exist_ok=True)

    try:
        for i in range(n_chunks):
            start = i * chunk_frames
            end = min(start + chunk_frames, total_frames)
            chunk = audio[start:end]
            chunk_path = os.path.join(tmp_dir,
                                      "chunk_{:04d}.wav".format(i))
            sf.write(chunk_path, chunk, sr)

            pct = 10 + int((i / n_chunks) * 80)
            emit(pct, "Separating chunk {}/{}...".format(
                i + 1, n_chunks))

            kwargs = dict(model=model_name, providers=providers,
                          precision=precision, progress=False)
            result = demucs_onnx.separate(chunk_path, tmp_dir, **kwargs)

            for stem_name, stem_path in _normalize_result(
                    result).items():
                data, _ = sf.read(stem_path, dtype="float32",
                                  always_2d=True)
                stem_chunks.setdefault(stem_name, []).append(data)

            try:
                os.remove(chunk_path)
            except OSError:
                pass

        emit(92, "Writing final stems...")
        out_paths = {}
        for stem_name, chunks in stem_chunks.items():
            combined = np.concatenate(chunks, axis=0)
            out_path = os.path.join(output_dir, stem_name + ".wav")
            sf.write(out_path, combined, sr)
            out_paths[stem_name] = out_path

        emit(100, "Done")
        return out_paths
    finally:
        try:
            shutil.rmtree(tmp_dir, ignore_errors=True)
        except Exception:
            pass


def _normalize_result(result):
    if isinstance(result, dict):
        return {k: v for k, v in result.items()
                if isinstance(v, str) and os.path.exists(v)}
    if isinstance(result, (list, tuple)):
        out = {}
        for item in result:
            if isinstance(item, (list, tuple)) and len(item) == 2:
                name, path = item
                if isinstance(path, str) and os.path.exists(path):
                    out[str(name)] = path
            elif isinstance(item, str) and os.path.exists(item):
                name = os.path.splitext(os.path.basename(item))[0]
                out[name] = item
        return out
    return {}
