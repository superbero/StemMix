"""QThread workers."""
import os
import traceback

from PyQt6.QtCore import QThread, pyqtSignal

from core.separation import separate_file
from core.export import render_mix_to_wav, encode_with_ffmpeg


class SeparationWorker(QThread):
    finished_ok = pyqtSignal(dict)
    failed = pyqtSignal(str)
    progress = pyqtSignal(int, str)

    def __init__(self, input_file, output_dir, model_name,
                 providers="auto", precision="fp32", chunked=False):
        super().__init__()
        self.input_file = input_file
        self.output_dir = output_dir
        self.model_name = model_name
        self.providers = providers
        self.precision = precision
        self.chunked = chunked

    def run(self):
        try:
            def cb(pct, msg):
                self.progress.emit(pct, msg)
            result = separate_file(
                self.input_file, self.output_dir, self.model_name,
                providers=self.providers, precision=self.precision,
                chunked=self.chunked, progress_cb=cb)
            self.finished_ok.emit(result)
        except Exception as e:
            traceback.print_exc()
            self.failed.emit(str(e))


class ExportWorker(QThread):
    progress = pyqtSignal(int)
    finished_ok = pyqtSignal(str)
    failed = pyqtSignal(str)

    def __init__(self, tracks, dsp_chains, output_path,
                 fmt_key, bitrate):
        super().__init__()
        self.tracks = tracks
        self.dsp_chains = dsp_chains
        self.output_path = output_path
        self.fmt_key = fmt_key
        self.bitrate = bitrate

    def run(self):
        tmp_wav = self.output_path + ".tmp.wav"
        try:
            def p1(p):
                self.progress.emit(int(p * 0.6))
            ok = render_mix_to_wav(
                self.tracks, self.dsp_chains, tmp_wav,
                progress_cb=p1)
            if not ok:
                self.failed.emit("No active tracks to export.")
                return

            def p2(p):
                self.progress.emit(60 + int(p * 0.4))
            ok = encode_with_ffmpeg(
                tmp_wav, self.output_path, self.fmt_key,
                self.bitrate, progress_cb=p2)
            if not ok:
                self.failed.emit("FFmpeg encoding failed.")
                return
            self.finished_ok.emit(self.output_path)
        except Exception as e:
            traceback.print_exc()
            self.failed.emit(str(e))
        finally:
            if os.path.exists(tmp_wav):
                try:
                    os.remove(tmp_wav)
                except OSError:
                    pass
